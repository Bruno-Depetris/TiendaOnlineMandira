﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace amb_personas_vehiculos
{
    public partial class AltaVehiculos : Form
    {
        private SqlConnection _conn = new SqlConnection(@"Data Source=ACADEMICA-08\SQLEXPRESS;Initial Catalog=Ejercicio1;User ID=sa;Password=utn");

        public AltaVehiculos()
        {
            InitializeComponent();
        }

        private void AltaVehiculos_Load(object sender, EventArgs e)
        {
            CargarPersonas();
        }

        private void CargarPersonas()
        {
            string query = "SELECT * FROM Persona";

            try
            {
                _conn.Open();
                SqlCommand _command = new SqlCommand(query, _conn);
                SqlDataReader _reader = _command.ExecuteReader();

                while (_reader.Read())
                {
                    comboBox1.Items.Add($"{_reader["id"]} - {_reader["Apellido"].ToString().Trim()} {_reader["Nombre"].ToString().Trim()}");
                }

                _reader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                _conn.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text) || string.IsNullOrEmpty(textBox2.Text) || string.IsNullOrEmpty(textBox3.Text))
            {
                MessageBox.Show("Todos los campos deben ser completados.");
                return;
            }

            if (!int.TryParse(textBox3.Text, out int anio))
            {
                MessageBox.Show("El año debe ser un número válido.");
                return;
            }

            string idPersonaStr = comboBox1.SelectedItem.ToString().Split('-')[0];
            int idPersona = int.Parse(idPersonaStr);
            Vehiculo vehiculo = new Vehiculo(textBox1.Text, textBox2.Text, anio, idPersona);

            CrearVehiculo(vehiculo);
        }

        private void CrearVehiculo(Vehiculo vehiculo)
        {
            string query = $"INSERT INTO Vehiculo (Marca, Modelo, Anio, id_persona) VALUES ('{vehiculo.Marca}', '{vehiculo.Modelo}', {vehiculo.Anio}, {vehiculo.Id})";

            try
            {
                _conn.Open();
                SqlCommand _command = new SqlCommand(query, _conn);
                _command.ExecuteNonQuery();

                MessageBox.Show("Vehiculo creado con exito");
                LimpiarCampos();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                _conn.Close();
            }
        }

        private void LimpiarCampos()
        {
            textBox1.Text = string.Empty;
            textBox2.Text = string.Empty;
            textBox3.Text = string.Empty;
            comboBox1.SelectedIndex = -1;
        }
    }
}





//using System;
//using System.Data.SqlClient;
//using System.Windows.Forms;

//namespace amb_personas_vehiculos
//{
//    public partial class AltaVehiculos : Form
//    {
//        SqlConnection _conn = new SqlConnection(@"Data Source=ACADEMICA-08\SQLEXPRESS;Initial Catalog=Ejercicio1;User ID=sa;Password=utn");
//        public AltaVehiculos()
//        {
//            InitializeComponent();
//        }

//        private void AltaVehiculos_Load(object sender, EventArgs e)
//        {
//            CargarPersonas();
//        }

//        private void CargarPersonas()
//        {
//            string query = "SELECT * FROM Persona";

//            try
//            {
//                _conn.Open();
//                SqlCommand _command = new SqlCommand(query, _conn);
//                SqlDataReader _reader = _command.ExecuteReader();

//                while (_reader.Read())
//                {
//                    comboBox1.Items.Add($"{_reader["id"]} - {_reader["Apellido"].ToString().Trim()} {_reader["Nombre"].ToString().Trim()}");
//                }

//                _conn.Close();
//            }
//            catch (Exception ex)
//            {
//                MessageBox.Show(ex.Message);
//            }
//        }

//        private void button2_Click(object sender, EventArgs e)
//        {
//            this.Close();
//        }

//        private void button1_Click(object sender, EventArgs e)
//        {
//            string marca = textBox1.Text;
//            string modelo = textBox2.Text;
//            int anio = int.Parse(textBox3.Text);

//            string idPersona = comboBox1.SelectedItem.ToString().Split('-')[0];

//            string query = $"INSERT INTO Vehiculo (Marca, Modelo, Anio, id_persona) VALUES ('{marca}', '{modelo}', {anio}, {idPersona})";

//            try
//            {
//                _conn.Open();
//                SqlCommand _command = new SqlCommand(query, _conn);
//                _command.ExecuteNonQuery();

//                MessageBox.Show("Vehiculo creado con exito");

//                _conn.Close();
//            }
//            catch (Exception ex)
//            {
//                MessageBox.Show(ex.Message);
//            }

//        }
//    }
//}
