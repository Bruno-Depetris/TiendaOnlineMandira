﻿using System;
using System.Windows.Forms;

namespace amb_personas_vehiculos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void crearPersonaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AltaPersonas altaPersonas = new AltaPersonas();
            altaPersonas.MdiParent = this;
            altaPersonas.Show();
        }

        private void crearVehiculoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AltaVehiculos altaVehiculos = new AltaVehiculos();
            altaVehiculos.MdiParent = this;
            altaVehiculos.Show();
        }

        private void verTodosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TablaVehiculos tablaVehiculos = new TablaVehiculos();
            tablaVehiculos.MdiParent = this;
            tablaVehiculos.Show();
        }

        private void verTodasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TablaPersonas tablaPersonas = new TablaPersonas();
            tablaPersonas.MdiParent = this;
            tablaPersonas.Show();
        }

        private void modificarPersonaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ModificarPersona modificarPersona = new ModificarPersona();
            modificarPersona.MdiParent = this;
            modificarPersona.Show();
        }
    }
}
