﻿using amb_personas_vehiculos.Logica;
using amb_personas_vehiculos.Modelos;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace amb_personas_vehiculos
{
    public partial class TablaPersonas : Form
    {
        public TablaPersonas()
        {
            InitializeComponent();
            CargarPersonas();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void CargarPersonas()
        {
            LogicaPersona logicaPersona = new LogicaPersona();

            foreach(Persona persona in logicaPersona.ObtenerPersonas())
            {
                dataGridView1.Rows.Add(persona.Nombre, persona.Apellido, persona.Edad);
            }
        }
    }
}

