﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace amb_personas_vehiculos
{
    public partial class ModificarPersona : Form
    {
        SqlConnection _conn = new SqlConnection(@"Data Source=ACADEMICA-08\SQLEXPRESS;Initial Catalog=Ejercicio1;User ID=sa;Password=utn");
        int idPersona = 0;
        public ModificarPersona()
        {
            InitializeComponent();
            CargarPersonas();
        }

        private void LimpiarCampos()
        {
            textBox1.Text = string.Empty;
            textBox2.Text = string.Empty;
            textBox3.Text = string.Empty;
        }

        private void CargarPersonas()
        {
            string query = "SELECT * FROM Persona";

            try
            {
                _conn.Open();
                SqlCommand _command = new SqlCommand(query, _conn);
                SqlDataReader _reader = _command.ExecuteReader();

                while (_reader.Read())
                {
                    comboBox1.Items.Add($"{_reader["id"]} - {_reader["Apellido"]} - {_reader["Nombre"]} - {_reader["Edad"]}");
                }
                _conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string[] valores = comboBox1.SelectedItem.ToString().Split('-');
            idPersona = int.Parse(valores[0]);
            textBox1.Text = valores[1];
            textBox2.Text = valores[2];
            textBox3.Text = valores[3];
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string query = $"UPDATE Persona SET Apellido = '{textBox1.Text}', Nombre = '{textBox2.Text}', Edad = {textBox3.Text} WHERE id = {idPersona}";

            try
            {
                _conn.Open();
                SqlCommand _command = new SqlCommand(query, _conn);
                _command.ExecuteNonQuery();
                _conn.Close();
                MessageBox.Show("Se modifico correctamente");
                comboBox1.Items.Clear();
                CargarPersonas();
                LimpiarCampos();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
    }
}
