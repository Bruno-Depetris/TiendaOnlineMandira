﻿namespace amb_personas_vehiculos.Modelos
{
    public class Persona
    {
        public int Id;
        public string Nombre;
        public string Apellido;
        public int Edad;

        public Persona(string nombre, string apellido, int edad)
        {
            Nombre = nombre;
            Apellido = apellido;
            Edad = edad;
        }
    }
}
