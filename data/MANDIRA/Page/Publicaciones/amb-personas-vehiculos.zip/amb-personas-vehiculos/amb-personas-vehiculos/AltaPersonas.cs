﻿using amb_personas_vehiculos.Logica;
using amb_personas_vehiculos.Modelos;
using System;
using System.Windows.Forms;

namespace amb_personas_vehiculos
{
    public partial class AltaPersonas : Form
    {
        public AltaPersonas()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("El apellido no puede ser vacío");
                return;
            }
            if (string.IsNullOrEmpty(textBox2.Text))
            {
                MessageBox.Show("El nombre no puede ser vacío");
                return;
            }
            if (!int.TryParse(textBox3.Text, out int edad))
            {
                MessageBox.Show("La edad no puede ser vacía");
                return;
            }

            Persona persona = new Persona(textBox2.Text, textBox1.Text, edad);

            try
            {
                LogicaPersona logicaPersona = new LogicaPersona();
                logicaPersona.CrearPersona(persona);
                MessageBox.Show("Persona creada con exito");
                LimpiarCampos();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void LimpiarCampos()
        {
            textBox1.Text = string.Empty;
            textBox2.Text = string.Empty;
            textBox3.Text = string.Empty;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
