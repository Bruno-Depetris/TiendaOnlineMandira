﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace amb_personas_vehiculos
{
    public partial class TablaVehiculos : Form
    {
        SqlConnection _conn = new SqlConnection(@"Data Source=ACADEMICA-08\SQLEXPRESS;Initial Catalog=Ejercicio1;User ID=sa;Password=utn");

        public TablaVehiculos()
        {
            InitializeComponent();
            CargarVehiculos();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void CargarVehiculos()
        {
            string query = "SELECT A.*, CONCAT(B.Nombre, ' ', B.Apellido) as NombrePersona " +
                "FROM Vehiculo A " +
                "LEFT JOIN Persona B " +
                "ON A.id_persona = B.id";

            try
            {
                _conn.Open();

                SqlCommand _command = new SqlCommand(query, _conn);
                SqlDataReader _reader = _command.ExecuteReader();

                while (_reader.Read())
                {
                    dataGridView1.Rows.Add(_reader["Marca"], _reader["Modelo"], _reader["Anio"], _reader["NombrePersona"], _reader["id"]);
                }

                _conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow != null)
            {
                DialogResult seleccion = MessageBox.Show("¿Desea borrar el registro?", "Cuidado", MessageBoxButtons.YesNo);
                if (seleccion == DialogResult.Yes)
                {
                    string id = dataGridView1.CurrentRow.Cells["id"].Value.ToString();

                    string deleteQuery = $"DELETE FROM Vehiculo WHERE ID = {id}";

                    try
                    {
                        _conn.Open();
                        SqlCommand deleteCommand = new SqlCommand(deleteQuery, _conn);
                        int filasAfecatadas = deleteCommand.ExecuteNonQuery();

                        if (filasAfecatadas > 0)
                        {
                            MessageBox.Show("Registro eliminado con exitosamente");
                            dataGridView1.Rows.RemoveAt(dataGridView1.CurrentRow.Index);
                        }
                        else
                        {
                            MessageBox.Show("No se pudo eliminar el registro");
                        }
                        _conn.Close();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("Debe seleccionar un registro");
            }
        }
    }
}
