﻿using amb_personas_vehiculos.Modelos;
using System.Collections;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Threading;

namespace amb_personas_vehiculos.Logica
{
    public class LogicaPersona
    {
        SqlConnection _conn = new SqlConnection(@"Data Source=ACADEMICA-08\SQLEXPRESS;Initial Catalog=Ejercicio1;User ID=sa;Password=utn");

        public void CrearPersona(Persona persona)
        {
            string query = $"INSERT INTO Persona (Apellido, Nombre, Edad) VALUES ('{persona.Apellido}', '{persona.Nombre}', {persona.Edad})";

            _conn.Open();
            SqlCommand _command = new SqlCommand(query, _conn);
            _command.ExecuteNonQuery();

            _conn.Close();
        }

        public List<Persona> ObtenerPersonas()
        {
            //ArrayList _personas = new ArrayList();
            List<Persona> _personas = new List<Persona>();
            string query = "SELECT * FROM Persona";

            _conn.Open();
            SqlCommand _command = new SqlCommand(query, _conn);
            SqlDataReader _reader = _command.ExecuteReader();

            while (_reader.Read())
            {
                string nombre = _reader["Nombre"].ToString();
                string apellido = _reader["Apellido"].ToString();
                int edad = int.Parse(_reader["Edad"].ToString());

                Persona persona = new Persona(nombre, apellido, edad);
                persona.Id = int.Parse(_reader["Id"].ToString());


                _personas.Add(persona);
            }

            _conn.Close();

            return _personas;
        }
    }
}
